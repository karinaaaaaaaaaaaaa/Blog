function openarticles(){
    window.location.href='index.html';
}
function openreviews(){
    window.location.href='reviews.html';
}
function openmedia(){
    window.location.href='media.html';
}